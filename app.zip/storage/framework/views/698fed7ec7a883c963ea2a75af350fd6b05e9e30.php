<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <div>
        <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200">
            <div class="container mx-auto px-6 py-2">
                <div class="text-right">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('FrontUser create')): ?>
                    <a href="<?php echo e(route('admin.front-users.create')); ?>" class="bg-pink-900 text-white font-bold px-5 py-1 rounded-full focus:outline-none shadow hover:bg-blue-400 transition-colors"><span class="far fa-user"></span> Add User</a>
                  <?php endif; ?>
                </div>

              <div class="bg-white shadow-md rounded my-6">
                <table class="text-left w-full border-collapse">
                  <thead>
                    <tr>
                      <th class="py-4 px-6 bg-grey-lightest font-bold text-sm text-grey-dark border-b border-grey-light">User Id</th>
                      <th class="py-4 px-6 bg-grey-lightest font-bold text-sm text-grey-dark border-b border-grey-light">User Name</th>
                      <th class="py-4 px-6 bg-grey-lightest font-bold text-sm text-grey-dark border-b border-grey-light">Email</th>
                      <th class="py-4 px-6 bg-grey-lightest font-bold text-sm text-grey-dark border-b border-grey-light text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('FrontUser access')): ?>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr class="hover:bg-grey-lighter">
                        <td class="py-4 px-6 border-b border-grey-light"><?php echo e($user->id); ?></td>
                        <td class="py-4 px-6 border-b border-grey-light"><?php echo e($user->name); ?></td>
                        <td class="py-4 px-6 border-b border-grey-light"><?php echo e($user->email); ?></td>
                        <td class="py-4 px-6 border-b border-grey-light text-right">
                          
                          <a title="User Browser History" href="<?php echo e(route('admin.userBrowserHistory',$user->id)); ?>" class="border border-transparent py-1 px-3 hover:border-green-400 text-green-400"><span class="fas fa-history"></span></a>

                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('FrontUser edit')): ?>
                          <a title="User Edit" href="<?php echo e(route('admin.front-users.edit',$user->id)); ?>" class="border border-transparent py-1 px-3 hover:border-blue-400 text-blue-400"><span class="fas fa-edit"></span></a>
                          <?php endif; ?>
                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('FrontUser delete')): ?>
                          <form action="<?php echo e(route('admin.front-users.destroy', $user->id)); ?>" method="POST" class="inline">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('delete'); ?>
                              <button title="User Delete" class="border border-transparent py-1 px-3 hover:border-pink-400 text-red-400"><span class="far fa-trash"></span></button>
                          </form>
                          <?php endif; ?>

                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                  </tbody>
                </table>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('FrontUser access')): ?>
                <div class="text-right p-4 py-10">
                  <?php echo e($users->links()); ?>

                </div>
                <?php endif; ?>
              </div>
  
            </div>
        </main>
    </div>
</div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\cashronic\resources\views/setting/front-user/index.blade.php ENDPATH**/ ?>