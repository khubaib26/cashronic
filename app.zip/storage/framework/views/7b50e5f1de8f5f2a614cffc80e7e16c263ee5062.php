<?php if (isset($component)) { $__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FrontLayout::class, []); ?>
<?php $component->withName('front-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                        <div class="mb-5">
                            <h2 class="text-xl font-bold text-blue-400 mb-2">Hi <?php echo e(Auth::guard('front')->user()->name); ?>  </h2>
                            <p>Welcome to your Cash Back Account. You're logged in!</p>
                        </div>
                        <div class="md:text-right p-3 bg-blue-400 rounded mb-5">
                             API Token: <?php echo e(session()->get('api_access_token')); ?>

                        </div>
                    </div>
                    <hr class="mb-5">
                    <div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                            <div>
                                <h1 class="text-2xl mb-5">Available  Stores</h1>
                            </div>
                            <div>
                                <h1 class="text-right mb-5"><a class="hover:text-blue-400" href="#">See All <span class="fas fa-chevron-right"></span></a></h1>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 md:grid-cols-5 gap-4 items-center">     
                        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <div class="relative h-24 p-5 shadow-lg border rounded flex items-center mb-1">
                                    <a href="<?php echo e($store->url); ?>" target="_blank">
                                        <img src="/store/<?php echo e($store->logo); ?>" alt="<?php echo e($store->name); ?>">
                                    </a>
                                    <a href="<?php echo e(route('favoriteStore',$store->id)); ?>" class="absolute -top-3 -right-2 rounded-full border border-transparent py-1 px-2 <?php echo $store->like ? 'bg-blue-200 hover:border-blue-400 text-blue-400' : 'bg-red-200 hover:border-red-400 text-red-400'; ?>">
                                        <?php echo $store->like ? '<span class="fas fa-heart"></span>' : '<span class="far fa-heart"></span>'; ?>

                                        
                                    </a>
                                </diV>
                                <div class="mb-5">
                                    <span class="fas fa-plus"></span> 30% Cash Back
                                </div>  
                            </div>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>
                    </div>
                    <hr class="mb-5">
                    <div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                            <div>
                                <h1 class="text-2xl mb-5">Your Favorites Stores</h1>
                            </div>
                            <div>
                                <h1 class="text-right mb-5"><a class="hover:text-blue-400" href="#">See All <span class="fas fa-chevron-right"></span></a></h1>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                        <?php $__currentLoopData = $favoriteStore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fstore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <div class="relative h-24 p-5 shadow-lg border rounded flex items-center mb-1">
                                    <a href="<?php echo e($fstore->url); ?>" target="_blank">
                                        <img class="w-48" src="/store/<?php echo e($fstore->logo); ?>" alt="<?php echo e($fstore->name); ?>">
                                    </a>
                                    <a href="<?php echo e(route('favoriteStore',$fstore->id)); ?>" class="absolute -top-3 -right-2 rounded-full border border-transparent py-1 px-2 <?php echo $fstore->like ? 'bg-blue-200 hover:border-blue-400 text-blue-400' : 'bg-red-200 hover:border-red-400 text-red-400'; ?>">
                                        <?php echo $fstore->like ? '<span class="fas fa-heart"></span>' : '<span class="far fa-heart"></span>'; ?>

                                        
                                    </a>
                                    <div class="absolute -bottom-3 right-0 rounded-full bg-blue-200 py-1 px-3 shadow text-pink-900 font-bold">
                                        <span class="fas fa-plus"></span> 30% Cash Back
                                    </div>
                                </diV>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>
                    </div>

                </div>  
            </div>    
        </div>   
    </div>
 <?php if (isset($__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a)): ?>
<?php $component = $__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a; ?>
<?php unset($__componentOriginal427056743380f0127f5c6367fdb385e78ff8dc7a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\cashronic\resources\views/front/dashboard.blade.php ENDPATH**/ ?>