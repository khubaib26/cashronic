<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <div>
        <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200">
            <div class="container mx-auto px-6 py-2">
                

              <div class="bg-white shadow-md rounded my-6">
                <table class="text-left w-full border-collapse">
                  <thead>
                    <tr>
                      <th class="py-4 px-6 bg-grey-lightest font-bold text-sm text-grey-dark border-b border-grey-light">Id</th>
                      <th class="py-4 px-6 bg-grey-lightest font-bold text-sm text-grey-dark border-b border-grey-light">Link</th>
                      <th class="py-4 px-6 bg-grey-lightest font-bold text-sm text-grey-dark border-b border-grey-light">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('FrontUser access')): ?>
                      <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr class="hover:bg-grey-lighter">
                        <td class="py-4 px-6 border-b border-grey-light"><?php echo e($history->id); ?></td>
                        <td class="py-4 px-6 border-b border-grey-light">
                          <a href="<?php echo e($history->link); ?>" target="_blank"><?php echo e($history->link); ?></a>
                        </td>
                        <td class="py-4 px-6 border-b border-grey-light"><?php echo e($history->created_at); ?></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                  </tbody>
                </table>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('FrontUser access')): ?>
                <div class="text-right p-4 py-10">
                  <?php echo e($histories->links()); ?>

                </div>
                <?php endif; ?>
              </div>
  
            </div>
        </main>
    </div>
</div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\cashronic\resources\views/setting/front-user/browserhistory.blade.php ENDPATH**/ ?>