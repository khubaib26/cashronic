
<img width="200" src="<?php echo e(asset('images/logo.png')); ?>" alt="<?php echo e(config('app.name')); ?>" <?php echo e($attributes); ?>>
<?php /**PATH D:\laragon\www\cashronic\resources\views/components/application-logo.blade.php ENDPATH**/ ?>