<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <div>
        <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200">
            <div class="container mx-auto px-6 py-1">
              <div class="bg-white shadow-md rounded my-6 p-5">
                <form method="POST" action="<?php echo e(route('admin.stores.store')); ?>" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('post'); ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                  <div>
                    <div class="flex flex-col space-y-2">
                    <label for="role_name" class="text-gray-700 select-none font-medium">Store Name</label>
                    <input
                      id="role_name"
                      type="text"
                      name="name"
                      value="<?php echo e(old('name')); ?>"
                      placeholder="Enter Store"
                      class="px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-200"
                    />
                    </div>
                  <div class="flex flex-col space-y-2">
                    <label for="role_name" class="text-gray-700 select-none font-medium">Store URL</label>
                    <input
                      id="url_name"
                      type="url"
                      name="url"
                      value="<?php echo e(old('url')); ?>"
                      placeholder="Enter Store URL"
                      class="px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-200"
                    />
                  </div>
                  <div class="flex flex-col space-y-2">
                    <label for="role_name" class="text-gray-700 select-none font-medium">Store Description</label>
                    <textarea 
                      name="description"
                      class="px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-200"
                    ></textarea>
                  </div></div>
                  <div> 
                    <div class="flex text-gray-500 mt-5 mx-auto order-first md:order-last">
                    <div class="bg-white rounded-lg mx-auto">
                      <div class="" x-data="imageData()">
                        <div x-show="previewUrl == '' && imgurl == ''">
                          <p class="text-center uppercase text-bold">
                            <label for="thumbnailprev" class="cursor-pointer">
                              Upload a file
                            </label>
                            <input type="file" name="logo" id="thumbnailprev" class="hidden thumbnailprev" @change="updatePreview()">
                          </p>
                        </div>
                        <div x-show="previewUrl !== ''" class="relative xw-40 xh-40">
                          <img :src="previewUrl" alt="" class="shadow-lg xrounded-full max-w-full h-auto align-middle border-4 h-full w-full object-cover">
                          <div class="xml-5 absolute top-0 right-0">
                            <button type="button" class="" @click="clearPreview()"><span class="fas fa-edit"></span></button>
                          </div>
                        </div>

                        <div x-show="imgurl !== ''" class="relative xw-40 xh-40">
                          <img :src="imgurl" alt="" class="shadow-lg xrounded-full max-w-full h-auto align-middle border-4 h-full w-full object-cover">
                          <div class="xml-5 absolute top-0 right-0">
                            <button type="button" class="" @click="clearPreview()"><span class="fas fa-edit"></span></button>
                          </div>
                        </div>

                      </div>
                    </div>
                  </div></div>
                </div>  
                  
                <h3 class="text-xl my-4 text-gray-600">Categories</h3>
                <div class="grid grid-cols-3 gap-4">
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="flex flex-col justify-cente">
                          <div class="flex flex-col">
                              <label class="inline-flex items-center mt-3">
                                  <input type="checkbox" class="form-checkbox h-5 w-5 text-pink-900" name="categories[]" value="<?php echo e($category->id); ?>"
                                  ><span class="ml-2 text-gray-700"><?php echo e($category->name); ?></span>
                              </label>
                              
                          </div>
                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="text-center mt-16">
                  <button type="submit" class="bg-pink-900 text-white font-bold px-5 py-1 rounded-full focus:outline-none shadow hover:bg-blue-400 transition-colors ">Submit</button>
                </div>
              </div>

             
            </div>
        </main>
    </div>
</div>

<script>
  function imageData() {
      var files = document.getElementById("thumbnailprev").files;
      if(files.length == 0){
          var url = '<?php echo e(asset("images/logo.png")); ?>';
      }else{
          url = '';
      }
    return {
      previewUrl: "",
      imgurl: url,
      updatePreview() {
        var reader, files = document.getElementById("thumbnailprev").files;
        reader = new FileReader();
        reader.onload = e => {
          this.previewUrl = e.target.result;
        };
        reader.readAsDataURL(files[0]);
      },
      clearPreview() {
        document.getElementById("thumbnailprev").value = null;
        this.previewUrl = "";
        this.imgurl     = "";
      }
    };
  }

</script>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\cashronic\resources\views/setting/store/new.blade.php ENDPATH**/ ?>